create function pattern(new_name character varying, new_password character varying, new_email character varying, new_created_at timestamp without time zone, new_updated_at timestamp without time zone, new_amount numeric) returns void
    language plpgsql
as
$$
begin
    INSERT into "users"("name", "password", "email", "created_at",
                        "updated_at", "amount") values (
                                                           new_name,
                                                           new_password,
                                                           new_email,
                                                           new_created_at,
                                                           new_updated_at,
                                                           new_amount
                                                       ) on conflict (name) do update
        set name = new_name,
            password = new_password,
            email = new_email,
            created_at = new_created_at,
            updated_at = new_updated_at,
            amount = new_amount;
end
$$;

alter function pattern(varchar, varchar, varchar, timestamp, timestamp, numeric) owner to postgres;

